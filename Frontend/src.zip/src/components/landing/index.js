export { default as Navbar } from './Navbar';
export { default as HeroSlider } from './HeroSlider';
export { default as CardSlider } from './CardSlider';
export { default as CategoriesGrid } from './CategoriesGrid';
export { default as ServicesList } from './ServicesList';
export { default as StepsTimeline } from './StepsTimeline';
export { default as PartnerSupport } from './PartnerSupport';
export { default as Footer } from './Footer';
export * from "./landingData.jsx"
